Samples : 

----------------------------------
List all nodes with metrics in XML :
----------------------------------

URL : http://localhost:8080/restservice-1.0/service/nodes.xml
METHOD : GET
BODY : <nill>

------------------------------------
List all nodes with metrics in JSON :
------------------------------------

URL : http://localhost:8080/restservice-1.0/service/nodes.json
METHOD : GET
BODY : <nill>

------------------------------------
List a particular node metric in XML :
------------------------------------

URL : http://localhost:8080/restservice-1.0/service/node/fqdn/aravind2.xml
METHOD : GET
BODY : <nill>

-------------------------------------
List a particular node metric in JSON :
-------------------------------------

URL : http://localhost:8080/restservice-1.0/service/node/fqdn/aravind2.json
METHOD : GET
BODY : <nill>

---------------------------
Insert new node using xml: 
---------------------------

URL : http://localhost:8080/restservice-1.0/service/node
METHOD : POST
BODY : 

<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ns2:node xmlns:ns2="urn:model.rest.nbi.test.aravind.com">
	<fqdn>aravind2</fqdn>
	<metric>
		<cpu>
			<core1>core1</core1>
			<core2>core2</core2>
		</cpu>
		<memory>
			<used>84.09064115267623%</used>
			<free>35.45218075919263%</free>
		</memory>
	</metric>
</ns2:node>

------------------------
Update Existing Node : 
------------------------

URL : http://localhost:8080/restservice-1.0/service/node
METHOD : PUT
BODY :

<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ns2:node xmlns:ns2="urn:model.rest.nbi.test.aravind.com">
	<fqdn>aravind2</fqdn>
	<metric>
		<cpu>
			<core1>core1</core1>
			<core2>core2</core2>
		</cpu>
		<memory>
			<used>84.09064115267623%</used>
			<free>35.45218075919263%</free>
		</memory>
	</metric>
</ns2:node>

------------------------
Delete Existing Node : 
------------------------

URL : http://localhost:8080/restservice-1.0/service/node/fqdn/aravind2
METHOD : DELETE
BODY :  <nill>