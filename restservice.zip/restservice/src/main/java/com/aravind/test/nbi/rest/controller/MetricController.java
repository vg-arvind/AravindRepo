package com.aravind.test.nbi.rest.controller;

import java.io.StringReader;
import java.util.List;
import java.util.UUID;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.PathVariable;

import com.aravind.test.nbi.rest.model.Cpu;
import com.aravind.test.nbi.rest.model.Memory;
import com.aravind.test.nbi.rest.model.Metric;
import com.aravind.test.nbi.rest.model.Node;
import com.aravind.test.nbi.rest.model.Nodes;
import com.aravind.test.nbi.rest.temp.ds.MetricDS;

/**
 * The ceontroller class that defines all the operations that are allowed.
 * 
 * 
 */

@Controller
public class MetricController {

	private static MetricDS metricDS = new MetricDS();

	private static final String XML_VIEW_NAME = "restXmlMarshalView";
	private Jaxb2Marshaller jaxb2Mashaller;

	public Jaxb2Marshaller getJaxb2Mashaller() {
		return jaxb2Mashaller;
	}

	public void setJaxb2Mashaller(Jaxb2Marshaller jaxb2Mashaller) {
		this.jaxb2Mashaller = jaxb2Mashaller;
	}

	@RequestMapping(method=RequestMethod.GET, value="/randomNode")
	public ModelAndView retrieveRandomMetric() {
		Metric metric = new Metric();
		Cpu cpu = new Cpu();
		cpu.setCore1("core1");
		cpu.setCore2("core2");
		metric.setCpu(cpu);
		Memory memory = new Memory();
		memory.setFree(Math.random()*100+"%");
		memory.setUsed(Math.random()*100+"%");
		metric.setMemory(memory);

		Node node = new Node();
		node.setMetric(metric);
		node.setFqdn(UUID.randomUUID().toString());

		return new ModelAndView(XML_VIEW_NAME, "object", node);
	}

	@RequestMapping(method=RequestMethod.POST, value="/node")
	public ModelAndView create(@RequestBody String body) {
		Source source = new StreamSource(new StringReader(body));
		Node node = (Node) getJaxb2Mashaller().unmarshal(source);
		metricDS.add(node);
		return new ModelAndView(XML_VIEW_NAME, "object", node);
	}

	@RequestMapping(method=RequestMethod.GET, value="/nodes")
	public ModelAndView retrieveAll() {
		List<Node> nodes = metricDS.getAll();
		Nodes list = new Nodes();
		list.getNodes().addAll(nodes);
		return new ModelAndView(XML_VIEW_NAME, "object", list);
	}

	@RequestMapping(method=RequestMethod.GET, value = "/node/fqdn/{fqdn}")
	public ModelAndView retrieveByPrimaryKey(@PathVariable("fqdn") String key) {
		Node node = metricDS.getNode(key);
		return new ModelAndView(XML_VIEW_NAME, "object", node);
	}

	@RequestMapping(method=RequestMethod.PUT, value="/node")
	public ModelAndView update(@RequestBody String body) {
		Source source = new StreamSource(new StringReader(body));
		Node node = (Node) getJaxb2Mashaller().unmarshal(source);
		metricDS.update(node);
		return new ModelAndView(XML_VIEW_NAME, "object", node);
	}


	@RequestMapping(method=RequestMethod.DELETE, value="/node/fqdn/{fqdn}")
	public ModelAndView delete(@PathVariable("fqdn") String fqdn) {
		Node node = metricDS.remove(fqdn);
		return new ModelAndView(XML_VIEW_NAME, "object", node);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

