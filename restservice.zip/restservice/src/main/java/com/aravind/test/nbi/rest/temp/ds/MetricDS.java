package com.aravind.test.nbi.rest.temp.ds;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aravind.test.nbi.rest.model.Node;

/**
 * This is the temporary data store class.
 * 
 * This will be used to simulate the GET as well as POST operations.
 * 
 * For testing first insert records to simulate a collection of nodes.
 * 
 * The used GET to fetch individual nodes.
 * 
 */


public class MetricDS {

	private static Map<String, Node> nodesMap = new HashMap<String, Node>();

	public void add(Node node) {

		nodesMap.put(node.getFqdn(), node);
	}

	public List<Node> getAll(){
		return (new ArrayList<Node>(nodesMap.values()));
	}

	public Node getNode(String fqdn){
		return nodesMap.get(fqdn);
	}

	public Node remove(String ipAddress) {
		return nodesMap.remove(ipAddress);
	}

	public Node update(Node node) {
		return nodesMap.put(node.getFqdn(), node);
	}
}
